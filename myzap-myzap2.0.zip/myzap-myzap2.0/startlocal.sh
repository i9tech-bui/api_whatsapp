#!/bin/bash
docker-compose up --build myzap_2dev