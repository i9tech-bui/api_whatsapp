# Changelog
## 07/08/2022
- Correção bug de não gerar Qrcode da pagina /start
- Melhoria no Layout & Style da pagina /start

## 06/08/2022
- Implatação do auto instalador MyZap
- Alteração Readme.md

## 06/08/2022
- Inicio da Marcação Changelog
